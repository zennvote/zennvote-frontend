import axios from 'axios';

export function getVoteData(){
    // return axios.get('http://언젠가 주소가 나오겠지/getChoises');
    
}