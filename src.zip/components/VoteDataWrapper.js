import React, { Component } from 'react';

const VoteDataWrapper =({choises})=>{
    return (
        <div>
            {choises}
        </div>
    )
}

export default VoteDataWrapper;