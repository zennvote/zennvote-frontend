import VoteData from './VoteData';
import VoteDataWrapper from './VoteDataWrapper';

export{
    VoteData,
    VoteDataWrapper,
};