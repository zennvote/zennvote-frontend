import Vote from './Vote';

export{
    Vote
};