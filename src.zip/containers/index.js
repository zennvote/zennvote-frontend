import VoteDataContainer from '../containers/VoteDataContainer';

export{
    VoteDataContainer
};