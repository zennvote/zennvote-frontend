import React, { Component } from 'react';
import * as service from '../services/GetVoteData';
import { VoteDataWrapper} from '../components';

class VoteDataContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            choises:{
                a : '123',
                b:'asdf' 
            },
            fetching: false,
        };
    }

    componentDidMount() {
        this.fetchVoteData();
    }

    fetchVoteData = async () => {
        this.setState({
            fetching: true
        });

        try {
            const voteData = await Promise.all([
                service.getVoteData()
            ]);

            const choises = voteData.data;
            this.setState({
                choises,
                fetching: false
            });
        } catch (e) {
            this.setState({
                fetching: false
            });
        }
    }

    render() {
        const { choises } = this.state;
        return (
            <VoteDataWrapper choises={choises}/>
        );
    }
}

export default VoteDataContainer;